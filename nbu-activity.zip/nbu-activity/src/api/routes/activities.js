// src/api/routes/activities.js — TODO: implement in Phase 1
import { Router } from 'express';
import { verifyJWT } from '../middleware/auth.js';
const router = Router();
router.use(verifyJWT);
// GET /api/v1/activities
// POST /api/v1/activities
// GET /api/v1/activities/:id
// PUT /api/v1/activities/:id
// DELETE /api/v1/activities/:id
// POST /api/v1/activities/:id/session/open
// POST /api/v1/activities/:id/session/close
export default router;
