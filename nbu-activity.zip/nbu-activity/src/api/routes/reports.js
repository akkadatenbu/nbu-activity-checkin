// src/api/routes/reports.js — TODO: implement in Phase 3
import { Router } from 'express';
import { verifyJWT } from '../middleware/auth.js';
const router = Router();
router.use(verifyJWT);
// GET /api/v1/reports/:activityId/excel
// GET /api/v1/reports/:activityId/pdf
export default router;
