// src/api/routes/students.js — TODO: implement in Phase 1
import { Router } from 'express';
import { verifyJWT } from '../middleware/auth.js';
const router = Router();
router.use(verifyJWT);
// GET /api/v1/students/search?q=
export default router;
