// src/line-oa/webhook.js — TODO: implement in Phase 3
import { Router } from 'express';
const router = Router();
// POST /line/webhook
router.post('/', (req, res) => res.sendStatus(200));
export default router;
